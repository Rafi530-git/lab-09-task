package com.example.university.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Professor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String department;

    @OneToMany(mappedBy = "professor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Course> courses;

    public Professor() {}

    public Professor(String name, String department, List<Course> courses) {
        this.name = name;
        this.department = department;
        this.courses = courses;
        for (Course course : courses) {
            course.setProfessor(this);
        }
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
        for (Course course : courses) {
            course.setProfessor(this);
        }
    }
}
