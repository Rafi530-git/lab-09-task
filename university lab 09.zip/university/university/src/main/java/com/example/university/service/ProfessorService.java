package com.example.university.service;

import com.example.university.entity.Course;
import com.example.university.entity.Professor;
import com.example.university.repository.ProfessorRepository;
import com.example.university.repository.CourseRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProfessorService {

    private final ProfessorRepository professorRepository;
    private final CourseRepository courseRepository;

    public ProfessorService(ProfessorRepository professorRepository, CourseRepository courseRepository) {
        this.professorRepository = professorRepository;
        this.courseRepository = courseRepository;
    }

    public Professor addProfessor(Professor professor) {
        return professorRepository.save(professor);
    }

    public List<Course> getCoursesByProfessor(Long professorId) {
        return courseRepository.findByProfessorId(professorId);
    }
}
